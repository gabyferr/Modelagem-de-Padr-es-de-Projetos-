﻿using DecoratorSolucao.Produto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoraterSolucao.Produto
{
    public abstract class AcrescimoDecorator : Pizza
    {
        protected Pizza pizza { get; set; }
        public override abstract string getDescricao();
        public override abstract double getPreco();


    }
}
