﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorSolucao.IteratorModel
{
    public class ImpressoraDeAgregados
    {
        public static void iterar(Iterator iterator)
        {
            while (iterator.hasNext()) 
            {
                Console.WriteLine(iterator.next() + " ");
            }
        }
    }
}
