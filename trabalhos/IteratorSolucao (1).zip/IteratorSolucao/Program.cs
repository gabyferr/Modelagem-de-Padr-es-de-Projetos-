﻿using IteratorSolucao.IteratorModel;

List<int> lista = [1, 2, 3, 4, 5, 6, 7, 8, 9];
List<List<int>> matriz = [[1, 2, 3], [4, 5, 6],[ 7, 8, 9]];

Iterator listaInterator = new ListaIterator(lista);
Iterator matrizInterator = new MatrizIterator(matriz);

Console.WriteLine("Lista - vetor");
ImpressoraDeAgregados.iterar(listaInterator);

Console.WriteLine("Matriz");
ImpressoraDeAgregados.iterar(matrizInterator);
